requireUncached = (module) => {
  delete require.cache[require.resolve(module)];
  return require(module);
};
const fs = requireUncached('fs');
const { execSync } = require('child_process');
const util = require('./util');
const generate = require('./generate');
const search = require('./search');
const genericSearch = require('./genericSearch');
const path_project = require('path');

const baseUrl = process.env.BASE_URL;
const e2eFolder = process.env.E2E_FOLDER || '../e2e/exploratory';
const fileTestName = 'cytestion.cy.js';

const generateCode = () => {
  const pathToTmp = '../tmp/';
  const fileTestFinal = `${e2eFolder}/${fileTestName}`;
  const fileTestTmp = `${e2eFolder}/tmp/${fileTestName}`;
  const fileCatalog = `${path_project.resolve(__dirname, pathToTmp)}/catalog.json`;
  // to do: remove
  const fileCatalogGeneric = `${path_project.resolve(__dirname, pathToTmp)}/catalog-generic.json`;

  if (!fs.existsSync(fileTestTmp)) {
    fs.mkdirSync(`${e2eFolder}/tmp/`, { recursive: true });
    const executionMode = process.env.EXECUTION_MODE;
    let rootFile;
    if (executionMode === 'production') {
      rootFile = util.getRootTestFileProd();
    } else {
      rootFile = util.getRootTestFile();
    }
    fs.writeFileSync(fileTestTmp, rootFile);
    fs.writeFileSync(`${path_project.resolve(__dirname, pathToTmp)}/translate.json`, JSON.stringify({}));
  } else {
    let catalog = {};
    if (fs.existsSync(fileCatalog)) {
      const rawCatalog = fs.readFileSync(fileCatalog);
      catalog = JSON.parse(rawCatalog);
    }
    // to do: remove
    let catalogGeneric = {};
    if (fs.existsSync(fileCatalogGeneric)) {
      const rawCatalogGeneric = fs.readFileSync(fileCatalogGeneric);
      catalogGeneric = JSON.parse(rawCatalogGeneric);
    }

    const contentTestFile = fs.readFileSync(fileTestTmp).toString();
    const codeList = contentTestFile.split('//--CODE--');

    const header = codeList.shift();
    const footer = codeList.pop();

    let codeListProcessed = util.dataProcessor(codeList);

    let filesTmp = fs.readdirSync(path_project.resolve(__dirname, pathToTmp)).filter((file) => file !== '.gitignore');

    let filesTmpRead = readTmpFiles(filesTmp, search.searchContent);
    filesTmpRead = util.filterFilesByBaseUrl(baseUrl, filesTmpRead);

    // to do: remove
    let filesTmpReadGeneric = readTmpFiles(filesTmp, genericSearch.searchContent);
    filesTmpReadGeneric = util.filterFilesByBaseUrl(baseUrl, filesTmpReadGeneric);

    let newCodes = [];
    codeListProcessed.forEach((code) => {
      if (util.canContinue(code, filesTmpRead)) {
        const actualFile = filesTmpRead.find((file) => file.name === code.actualId.join('->'));
        if (actualFile) {
          generate.generateNewTestCodes(code, actualFile, newCodes, catalog);
        }

        // to do: remove
        catalogGenericFunction(code, filesTmpReadGeneric, catalogGeneric);
      }
    });

    if (newCodes.length > 0) {
      //generate new tests
      util.putSkipInTests(codeListProcessed);
      let result = [];
      result.push(header);
      result.push(...codeListProcessed.map((elem) => elem.codeText));
      result.push(...newCodes);
      result.push(footer);
      fs.writeFileSync(fileTestTmp, result.join('//--CODE--'));
      fs.writeFileSync(fileCatalog, JSON.stringify(catalog, null, 2));
      fs.writeFileSync(fileCatalogGeneric, JSON.stringify(catalogGeneric, null, 2));
    } else {
      if (fs.existsSync(fileCatalog)) fs.copyFileSync(fileCatalog, `${e2eFolder}/catalog.json`);
      if (fs.existsSync(fileCatalogGeneric)) fs.copyFileSync(fileCatalogGeneric, `${e2eFolder}/catalog-generic.json`);
      //clear final tests
      if (filesTmp.length > 0) {
        execSync(`rm -v ${path_project.resolve(__dirname, pathToTmp)}/*`);
      }
      let result = [];
      const codeListProcessedFiltered = util.filterAndClearCodeList(codeListProcessed);
      result.push(header);
      result.push(...codeListProcessedFiltered.map((elem) => elem.codeText));
      result.push('\n});');
      // execSync(`rm -R ${e2eFolder}/tmp`); prevent exclude tmp script test.
      fs.writeFileSync(fileTestFinal, result.join(''));
      execSync(`yarn format-file ${fileTestFinal}`, { stdio: 'pipe' });
    }
  }
};

const readTmpFiles = (filesTmp, searchContent) => {
  let generation;
  const result = [];
  const pathToTmp = '../tmp/';
  const rawdata = fs.readFileSync(`${path_project.resolve(__dirname, pathToTmp)}/translate.json`);
  const translate = JSON.parse(rawdata);

  Object.keys(translate).forEach((key) => {
    const current = (translate[key].match(/->/g) || []).length;
    if (!generation || current > generation) generation = current;
  });
  let filteredFilesTmp = filesTmp.filter((file) => file !== 'translate.json' && file !== 'catalog.json' && file !== 'catalog-generic.json');
  filteredFilesTmp = filteredFilesTmp.filter((file) => (translate[file]?.match(/->/g) || []).length === generation);

  filteredFilesTmp.forEach((file) => {
    const obj = {};
    obj.name = translate[file];
    obj.generation = generation;
    obj.parentContent = util.getParentContent(obj.name);
    obj.content = fs.readFileSync(path_project.resolve(__dirname, pathToTmp) + '/' + file).toString();
    searchContent(obj);

    result.push(obj);
  });

  return result;
};

const catalogGenericFunction = (code, filesTmp, catalogGeneric) => {
  const actualFileGeneric = filesTmp.find((file) => file.name === code.actualId.join('->'));
  if (actualFileGeneric) {
    actualFileGeneric.idClick.forEach((elem) => util.willNotGenerateDuplicate(util.extractUrl(elem), `[${elem.typeId}"${elem.id}"]`, elem.tag, catalogGeneric));
    actualFileGeneric.idText.forEach((elem) => util.willNotGenerateDuplicate(util.extractUrl(elem), elem.id, elem.tag, catalogGeneric));
    actualFileGeneric.idsForm.forEach((elem) => util.willNotGenerateDuplicate(util.extractUrl(elem), `[${elem.typeId}"${elem.id}"]`, elem.tag, catalogGeneric));
  }
};

generateCode();
