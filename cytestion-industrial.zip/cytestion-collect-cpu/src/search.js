const fs = require('fs');
const util = require('./util');
const path_project = require('path');
const ahocorasick = require('ahocorasick');
const rawLocators = fs.readFileSync(path_project.resolve(__dirname, '../config/locators.json'));
const locators = JSON.parse(rawLocators).dataCy;
const ac = new ahocorasick(locators);

const rawDictionary = fs.readFileSync(path_project.resolve(__dirname, '../config/dictionary.json'));
const json = JSON.parse(rawDictionary);
const keysData = Object.keys(json);

const searchContent = (obj) => {
  const listResult = ac.search(obj.content);

  let idStrings = listResult.map((elem) => {
    const newObj = {};
    newObj.id = util.getIdByIdx(obj.content, elem[0]);
    newObj.tag = util.getTagOfIdx(obj.content, elem[0]);
    newObj.twoTagsAbove = util.extractTwoTagsAbove(obj.content, elem[0]);
    newObj.typeId = elem[1][0];
    newObj.content = obj.content;

    return newObj;
  });

  // remove duplicates
  if (obj.generation > 0) idStrings = idStrings.filter((curr) => !obj.parentContent.includes(`${curr.typeId}"${curr.id}"`));

  // remove not actionables
  idStrings = idStrings.filter((curr) => !curr.tag.includes('readonly') && !curr.tag.includes('disabled') && !curr.tag.includes('visibility: hidden'));

  obj.idClick = [];
  obj.idsForm = [];
  obj.idText = [];

  idStrings.forEach((elem) => {
    const idxInput = elem.tag.indexOf('<input');
    const idxTextarea = elem.tag.indexOf('<textarea');
    const idxSelect = elem.tag.indexOf('<select');
    elem.isInput = idxInput !== -1 || idxTextarea !== -1 || idxSelect !== -1;
    if (elem.isInput) {
      if (idxInput !== 0) {
        elem.insideInputText = ' input';
      } else if (idxTextarea !== 0) {
        elem.insideInputText = ' textarea';
      } else if (idxSelect !== 0) {
        elem.insideInputText = ' select';
      }
      processTypeForm(elem, obj);
    } else {
      obj.idClick.push(elem);
    }
  });
};

const processTypeForm = (elem, obj) => {
  let key;
  let idxClass;
  let actualTag = elem.tag;
  const classString = 'class=';
  while (!key && idxClass !== -1) {
    idxClass = actualTag.indexOf(classString);
    if (idxClass !== -1) {
      const classInput = util.getIdByIdx(actualTag, idxClass);
      key = keysData.find((key) => classInput.includes(key));
      if (key) elem.classId = json[key];
      if (elem.classId === 'input') {
        if (elem.id.includes('input-cpf')) elem.classId = 'input-cpf';
        if (elem.id.includes('input-cnpj')) elem.classId = 'input-cnpj';
      }
      if (!key) {
        actualTag = actualTag.substr(idxClass + classString.length);
      }
    } else {
      key = keysData.find((key) => elem.twoTagsAbove.includes(key));
      if (key) elem.classId = json[key];
      else elem.classId = 'input';
    }
  }
  obj.idsForm.push(elem);
};

module.exports = {
  searchContent,
};
