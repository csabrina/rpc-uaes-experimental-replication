const fs = require('fs');
const util = require('./util');
const path_project = require('path');
const ahocorasick = require('ahocorasick');
const rawLocators = fs.readFileSync(path_project.resolve(__dirname, '../config/locators.json'));
const locators = JSON.parse(rawLocators);
const ac = { tag: new ahocorasick(locators.generic.tag), attributes: new ahocorasick(locators.generic.attributes), class: new ahocorasick(locators.generic.class) };
const rawSelectors = fs.readFileSync(path_project.resolve(__dirname, '../config/selectors.json'));
const selectors = JSON.parse(rawSelectors).selectors;
const rawdata = fs.readFileSync(path_project.resolve(__dirname, '../config/dictionary.json'));
const json = JSON.parse(rawdata);
const keysData = Object.keys(json);

const searchContent = (obj) => {
  const getByAttribute = (tagObj, triedSelectors = []) => {
    const objectifiedTag = util.objectifiesTagHtml(tagObj.tag.split('>')[0]);
    const attrFounded = selectors.filter(sel => !triedSelectors.includes(sel)).find((attr) => Object.keys(objectifiedTag).includes(attr));
    if (attrFounded && !objectifiedTag[attrFounded].includes('uuid')) {
      tagObj.id = objectifiedTag[attrFounded];
      tagObj.typeId = attrFounded + '=';
      // remove duplicates
      const existInParent = [...setParentResults].find((tag) => tag.includes(`${tagObj.typeId}"${tagObj.id}"`));
      if (obj.generation === 0 || !existInParent) {
        if (tagObj.isInput) processTypeForm(tagObj, obj);
        else obj.idClick.push(tagObj);
      } else {
        getByAttribute(tagObj, [...triedSelectors, attrFounded]);
      }
    } else {
      // Try create a selector using the childrens.
      childrenTag = tagObj.tag.substring(tagObj.tag.indexOf('>') + 1);
      if (childrenTag) {
        tagObj.tag = childrenTag;
        getByAttribute(tagObj);
      }
    }
  }

  let setResults = new Set();
  let setParentResults = new Set();

  locateActionableTags(obj.content, setResults);
  obj.generation > 0 && locateActionableTags(obj.parentContent, setParentResults);

  obj.idClick = [];
  obj.idText = [];
  obj.idsForm = []; // to do: implement

  [...setResults].forEach((tag) => {
    const tagObj = { tag: tag, content: obj.content };
    pointAsInput(tagObj);
    const text = util.getChildrenText(tag);
    if (text && !tagObj.isInput) {
      tagObj.id = text;
      tagObj.typeId = 'children-text';
      // remove duplicates
      const existInParent = [...setParentResults].find((tag) => util.getChildrenText(tag) === text);
      if (obj.generation === 0 || !existInParent) obj.idText.push(tagObj);
      else getByAttribute(tagObj);
    } else getByAttribute(tagObj);
    if (!tagObj.id) {
      fs.appendFileSync('selectorNotFound.txt', tag + '\n\n');
    }
  });
};

const pointAsInput = (tagObj) => {
  let tag = tagObj.tag;
  const idxInput = tag.indexOf('<input');
  const idxTextarea = tag.indexOf('<textarea');
  const idxSelect = tag.indexOf('<select');
  tagObj.isInput = idxInput !== -1 || idxTextarea !== -1 || idxSelect !== -1;
  if (tagObj.isInput) {
    if (idxInput !== 0) {
      tagObj.insideInputText = ' input';
    } else if (idxTextarea !== 0) {
      tagObj.insideInputText = ' textarea';
    } else if (idxSelect !== 0) {
      tagObj.insideInputText = ' select';
    }
  }
};

const processTypeForm = (elem, obj) => {
  let key;
  let idxClass;
  let actualTag = elem.tag;
  const typeString = 'type=';
  const idxType = elem.tag.indexOf(typeString);
  if (elem.tag.includes('<select')) {
    elem.classId = 'input-select';
  } else if (idxType !== -1) {
    const typeInput = util.getIdByIdx(elem.tag, idxType);
    if (typeInput === 'date') {
      elem.classId = 'input-picker';
    } else if (typeInput === 'number') {
      elem.classId = 'input-number';
    } else if (typeInput === 'submit') {
      elem.classId = 'input-submit';
    } else if (typeInput === 'input-checkbox') {
      elem.classId = 'input-submit';
    } else {
      elem.classId = 'input';
    }
  } else {
    const classString = 'class=';
    while (!key && idxClass !== -1) {
      idxClass = actualTag.indexOf(classString);
      if (idxClass !== -1) {
        const classInput = util.getIdByIdx(actualTag, idxClass);
        key = keysData.find((key) => classInput.includes(key));
        if (key) elem.classId = json[key];
        if (elem.classId === 'input') {
          if (elem.id.includes('input-cpf')) elem.classId = 'input-cpf';
          if (elem.id.includes('input-cnpj')) elem.classId = 'input-cnpj';
        }
        if (!key) {
          actualTag = actualTag.substr(idxClass + classString.length);
        }
      } else {
        key = keysData.find((key) => util.extractTwoTagsAbove(elem.content, elem.tag).includes(key));
        if (key) elem.classId = json[key];
        else elem.classId = 'input';
      }
    }
  }
  obj.idsForm.push(elem);
};

const locateActionableTags = (content, setResults) => {
  let results = [];
  Object.entries(ac).forEach(([kind, ahoDictionary]) => {
    let listResult = ahoDictionary.search(content);

    if (kind == 'attributes') {
      listResult = listResult.filter((elem) => {
        const index = elem[0];
        const attribute = elem[1][0];
        if (attribute.includes('=')) {
          if (attribute.at(-1) == '=') {
            let attributeValue = content[index + 1];
            do {
              attributeValue += content[index + 1 + attributeValue.length];
            } while (["'", '"', '>'].every((elem) => attributeValue.at(-1) != elem));
            return ["'", '"'].some((elem) => attributeValue.at(-1) == elem);
          } else {
            return content[index - attribute.length] == ' ' && [' ', '>'].some((elem) => content[index + 1] == elem);
          }
        } else return false;
      });
    } else if (kind == 'class') {
      listResult = listResult.filter((elem) => {
        const index = elem[0];
        let stringVerificacao = '';
        while (!stringVerificacao.includes('=ssalc') && !stringVerificacao.includes('<')) stringVerificacao += content[index - stringVerificacao.length];
        return !stringVerificacao.includes('<');
      });
    } else if (kind == 'tag') {
      listResult = listResult.filter((elem) => {
        const tag = elem[1][0];
        if (tag === '<a ') {
          return util.getTagOfIdx(content, elem[0]).includes('href=');
        }
        return true;
      });
    }

    let listTags = listResult.map((elem) => util.getTagOfIdx(content, elem[0]));

    // remove not actionables
    listTags = listTags.filter((tag) => !tag.includes('readonly') && !tag.includes('disabled') && !tag.includes('visibility: hidden') && !tag.includes('mailto:'));

    // to do: create a blacklist for selectors by ENV.
    listTags = listTags.filter((tag) => !tag.includes('Last Page'));

    results[kind] = listTags;
    results = results.concat(listTags);
  });

  util.filterStrings(results).forEach((tag) => setResults.add(tag));
};

module.exports = {
  searchContent,
};
