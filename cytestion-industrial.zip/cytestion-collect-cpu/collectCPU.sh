#!/bin/bash
sleep 5
count=0
while true; do
  pids=$(ps aux | grep Cypress | grep -v grep | awk '{print $2}')
  if [ -z "$pids" ]; then
    count=$((count+1))
    if [ $count -eq 30 ]; then
      break
    fi
    sleep 1
  else
    count=0
    for pid in $pids; do
      top -b -n 1 -p $pid > temp_top_output.txt
      cpu_and_status=$(grep  "$pid" temp_top_output.txt | awk '{print $8, $9, $10}')
      echo "$pid $cpu_and_status"
      rm temp_top_output.txt
    done
    echo
  fi
done
